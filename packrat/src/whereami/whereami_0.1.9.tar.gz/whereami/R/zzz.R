.onLoad <- function(libname, pkgname) {
  options(keep.source = TRUE)
}

.onAttach <- function(libname, pkgname) {
  options(keep.source = TRUE)
}
